from setuptools import setup


# Set up paquetes
setup(
    name = 'Mensajes',
    version= '1.0',
    description= 'Un paquete para saludar y despedir',
    author= 'Jose Armando Rosas Balderas',
    author_email= 'armando.rosas133@gmail.com',
    url= 'https://github.com/ArmandoRosasB',
    packages= ['Mensajes', 'Mensajes.Bienvenidas', 'Mensajes.Despedidas'],
    scripts= ['test.py']
)

# Para ejecutar el setup
# Generar el distribuible

'''
py setup.py sdist

'''