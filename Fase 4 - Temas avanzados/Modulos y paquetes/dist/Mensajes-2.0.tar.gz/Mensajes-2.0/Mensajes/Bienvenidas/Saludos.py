def saludar():
    print("Hola, te saludo desde saludos.saludar()")

# __name__ Almacena el nombre del script
# El nombre del ejecutable es __main__

def prueba():
    print("Esto es una prueba de la nueva version")

class Saludo:
    def __init__(self) -> None:
        print("Hola, te saludo desde Saludo.__init__()")




if __name__ == '__main__':
    saludar()