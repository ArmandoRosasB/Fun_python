def despedir():
    print("Adios, me despido desde Despedidas.despedir()")

class Despedida:
    def __init__(self) -> None:
        print("Adios, me despido desde Despedida.__init__()")